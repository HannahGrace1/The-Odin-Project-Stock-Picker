def stock_picker(prices)
  profit =0
  day = ""

  prices.each_with_index do  |num1, day1|
    prices.each_with_index do |num2, day2|
# num2 is the one you sell and num1 is the price you bought at
      end_profit= num2-num1

      if end_profit > profit and day1 < day2
        profit = end_profit
        day = [day1,day2]
      end
    end
  end
  p day
  day
end

    
stock_picker([17,3,6,9,15,8,6,1,10])
# => [1, 4]